<section class="content">
      <div class="error-page">
        <h1 class="headline text-yellow">404</h1>

        <div class="error-content">
          <h3><i class="fa fa-warning text-yellow"></i> Oops! Acho que você está perdido.</h3>

          <p>
           Não foi possível encontrar a página que você estava procurando.
            Enquanto isso, você pode <a href="?pg=inicio">retornar ao painel</a>
          </p>
        </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>